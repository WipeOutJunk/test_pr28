package com.example.pr28;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;

import android.os.Bundle;

import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final ImageView shipImageView = findViewById(R.id.shipImageView);
        final ImageView sunImageView = findViewById(R.id.sunImageView);

        // Анимация движения корабля
        ObjectAnimator shipAnimator = ObjectAnimator.ofFloat(shipImageView, "translationX", 2000f);
        shipAnimator.setDuration(5000);
        shipAnimator.start();

        // Анимация захода солнца
        ObjectAnimator sunAnimator = ObjectAnimator.ofFloat(sunImageView, "translationY", 0f, 300f); // движение солнца вниз
        sunAnimator.setDuration(5000);
        sunAnimator.start();

        // Анимация изменения масштаба для создания эффекта ухода солнца под воду
        ObjectAnimator scaleDownX = ObjectAnimator.ofFloat(sunImageView, "scaleX", 0.5f);
        ObjectAnimator scaleDownY = ObjectAnimator.ofFloat(sunImageView, "scaleY", 0.5f);
        scaleDownX.setDuration(5000);
        scaleDownY.setDuration(5000);

        AnimatorSet scaleDown = new AnimatorSet();
        scaleDown.play(scaleDownX).with(scaleDownY);
        scaleDown.start();
    }
}